# Dashboard Comparativo Operaciones vs Logística (Streamlit)

**Objetivo**: Identificar desequilibrios entre lo que se produce (operaciones) y lo que se mueve (logística) y visualizar el solapamiento con un diagrama Sankey.

## Ejecutar
```bash
pip install -r requirements.txt
streamlit run app.py
```
